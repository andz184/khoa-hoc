<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Danh sách bài học - <?php echo e($course->title); ?></h3>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <a href="<?php echo e(route('admin.courses.lessons.create', $course)); ?>" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Thêm bài học mới
                        </a>
                    </div>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped" id="lessons-table">
                            <thead>
                                <tr>
                                    <th style="width: 50px">STT</th>
                                    <th>Thumbnail</th>
                                    <th>Tiêu đề</th>
                                    <th>Link YouTube</th>
                                    <th>Link tải</th>
                                    <th>Thứ tự</th>
                                    <th>Trạng thái</th>
                                    <th>Hiển thị</th>
                                    <th>Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($lesson->id); ?>">
                                    <td class="handle" style="cursor: move;">
                                        <i class="fas fa-grip-vertical"></i>
                                    </td>
                                    <td>
                                        <?php if($lesson->thumbnail): ?>
                                            <img src="<?php echo e(asset('storage/' . $lesson->thumbnail)); ?>" alt="Thumbnail" class="img-thumbnail" style="max-width: 100px;">
                                        <?php else: ?>
                                            <span class="text-muted">Không có</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($lesson->title); ?></td>
                                    <td>
                                        <a href="<?php echo e($lesson->youtube_link); ?>" target="_blank">
                                            <i class="fab fa-youtube text-danger"></i> Xem video
                                        </a>
                                    </td>
                                    <td>
                                        <?php if($lesson->download_link): ?>
                                            <a href="<?php echo e(asset('storage/' . $lesson->download_link)); ?>"
                                               download="<?php echo e($lesson->original_filename); ?>"
                                               target="_blank">
                                                <i class="fas fa-download text-primary"></i> Tải xuống
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">Không có</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <input type="number" class="form-control form-control-sm sort-order-input"
                                               value="<?php echo e($lesson->sort_order); ?>"
                                               min="0"
                                               data-lesson-id="<?php echo e($lesson->id); ?>"
                                               style="width: 80px;">
                                    </td>
                                    <td>
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input publish-toggle"
                                                   id="publish_<?php echo e($lesson->id); ?>"
                                                   data-lesson-id="<?php echo e($lesson->id); ?>"
                                                   <?php echo e($lesson->is_published ? 'checked' : ''); ?>>
                                            <label class="custom-control-label" for="publish_<?php echo e($lesson->id); ?>"></label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input visibility-toggle"
                                                   id="visibility_<?php echo e($lesson->id); ?>"
                                                   data-lesson-id="<?php echo e($lesson->id); ?>"
                                                   <?php echo e($lesson->is_visible ? 'checked' : ''); ?>>
                                            <label class="custom-control-label" for="visibility_<?php echo e($lesson->id); ?>"></label>
                                        </div>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.courses.lessons.edit', [$course, $lesson])); ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.courses.lessons.destroy', [$course, $lesson])); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa bài học này?')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.14.0/Sortable.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Khởi tạo Sortable cho bảng
    const tbody = document.querySelector('#lessons-table tbody');
    new Sortable(tbody, {
        handle: '.handle',
        animation: 150,
        onEnd: function(evt) {
            updateSortOrder();
        }
    });

    // Cập nhật thứ tự khi thay đổi input
    document.querySelectorAll('.sort-order-input').forEach(input => {
        input.addEventListener('change', function() {
            updateSortOrder();
        });
    });

    // Hàm cập nhật thứ tự
    function updateSortOrder() {
        const rows = tbody.querySelectorAll('tr');
        const orders = Array.from(rows).map((row, index) => {
            const input = row.querySelector('.sort-order-input');
            return {
                id: row.dataset.id,
                sort_order: parseInt(input.value) || index
            };
        });

        // Gửi request cập nhật thứ tự
        fetch('<?php echo e(route("admin.courses.lessons.update-order", $course)); ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: JSON.stringify({ orders })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Cập nhật lại các giá trị sort_order
                data.orders.forEach(order => {
                    const input = document.querySelector(`tr[data-id="${order.id}"] .sort-order-input`);
                    if (input) {
                        input.value = order.sort_order;
                    }
                });
            }
        })
        .catch(error => console.error('Error:', error));
    }

    // Xử lý toggle publish
    document.querySelectorAll('.publish-toggle').forEach(toggle => {
        toggle.addEventListener('change', function() {
            const lessonId = this.dataset.lessonId;
            fetch(`<?php echo e(url('/admin123/courses')); ?>/<?php echo e($course->id); ?>/lessons/${lessonId}/toggle-publish`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Cập nhật trạng thái checkbox
                    this.checked = data.is_published;
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });

    // Xử lý toggle visibility
    document.querySelectorAll('.visibility-toggle').forEach(toggle => {
        toggle.addEventListener('change', function() {
            const lessonId = this.dataset.lessonId;
            fetch(`<?php echo e(url('/admin123/courses')); ?>/<?php echo e($course->id); ?>/lessons/${lessonId}/toggle-visibility`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Cập nhật trạng thái checkbox
                    this.checked = data.is_visible;
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\khoahoc\example-app22\resources\views/admin/lessons/index.blade.php ENDPATH**/ ?>