<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="<?php echo e(url('/')); ?>"><?php echo e(config('app.name', 'Laravel')); ?></a>.</strong> All rights reserved.
</footer>
<?php /**PATH C:\xampp\htdocs\khoahoc\example-app22\resources\views/layouts/partials/admin/footer.blade.php ENDPATH**/ ?>